'use strict';
exports.id = 'rmo';
exports.version = '0.9.0';
exports.ids = {
  chrome: [
    'cncfeggekcpklikifckffefgdkbfnhcp',  // internet downloader (chrome)
    'fbacnnnbkcihhabbaoenlhfifjjeccgi',  // internet downloader test version (chrome)
  ],
  firefox: [
    '{165e553c-8c91-4d66-8f47-1e60295562d3}', // download-by-idm
  ]
};