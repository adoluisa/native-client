'use strict';
exports.id = 'rmo';
exports.version = '0.9.0';
exports.ids = {
  chrome: [
    'cncfeggekcpklikifckffefgdkbfnhcp',  // 
    'ondoafhknncbfacjflhgmimfeopmeall'  // Internet Downloader test version (chrome)
  ],
  firefox: [
    '{b628bc36-bcdb-47bc-9c12-fcec30a0cc3f}', //Internet Downloader
  ]
};